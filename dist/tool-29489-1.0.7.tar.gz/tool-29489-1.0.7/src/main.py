import argparse
import includes.filereader as filereader
import includes.scan as scan

parser = argparse.ArgumentParser(description="This is a tool for cve-2023-29489")

parser.add_argument('-u','--url',metavar='URL to scan')
parser.add_argument('-i','--input',metavar='input_file to scan',help="Pass input file name")
parser.add_argument('-o','--output',metavar='output_file to write result',help="Pass the output file name")

args = parser.parse_args()

url = args.url
input_file = args.input
output_file = args.output 


def main():
    if url:
        scan.scanner(url,output_file)
    elif input_file:
        filereader.file_reader(input_file,output_file)

if __name__=="__main__":
    main()
    