
# def writetofile(vuln_url,outname):
#     if outname:
#         pass
#     else:
#         outname = 'output.txt'

#     with open(outname,'a') as file:
#         file.write(vuln_url+"\n")
        
