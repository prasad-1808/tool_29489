# from includes.scan import scanner

# def file_reader(input_file,output_file):
#     with open(input_file,'r') as file:
#         for url in file.readlines():
#             scanner(url.strip(),output_file)



